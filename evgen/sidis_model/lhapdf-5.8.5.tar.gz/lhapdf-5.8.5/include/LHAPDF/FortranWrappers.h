/* include/LHAPDF/FortranWrappers.h.  Generated from FortranWrappers.h.in by configure.  */
#ifndef LHAPDF_FORTRANWRAPPERS_H
#define LHAPDF_FORTRANWRAPPERS_H

/* Define to dummy `main' function (if any) required to link to the Fortran
   libraries. */
/* #undef FC_DUMMY_MAIN */

/* Define if F77 and FC dummy `main' functions are identical. */
/* #undef FC_DUMMY_MAIN_EQ_F77 */

/* Define to a macro mangling the given C identifier (in lower and upper
   case), which must not contain underscores, for linking with Fortran. */
#define FC_FUNC(name,NAME) name ## _

/* As FC_FUNC, but for C identifiers containing underscores. */
#define FC_FUNC_(name,NAME) name ## _

#endif
