/* include/LHAPDF/LHAPDFConfig.h.  Generated from LHAPDFConfig.h.in by configure.  */
#ifndef LHAPDF_LHAPDFCONFIG_H
#define LHAPDF_LHAPDFCONFIG_H

/* LHAPDF version string */
#define LHAPDF_VERSION "5.8.5"

/* Was LHAPDF built in low-memory mode? */
/* #undef LHAPDF_LOWMEM */

/* How many LHAPDF PDF sets can be used concurrently? */
#define LHAPDF_NMXSET "3"

#endif
