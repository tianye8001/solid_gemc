#!/bin/bash

#mypath=/home/nschroed/geant4/CaloSim
#cd $mypath
time ./bin/Linux-g++/CaloSim ./10000.mac /data/npluser2/nschroed/may/1e4.root