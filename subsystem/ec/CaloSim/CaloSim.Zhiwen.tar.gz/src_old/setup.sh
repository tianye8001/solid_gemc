setenv G4INSTALL /scratch/compiling/geant4.7.0.p01site/local/pkg/geant4/Linux=x86_64-Boron/geant4.9.2.p01
setenv CLHEP_BASE_DIR /scratch/compiling/CLHEP_INSTALL/
setenv CLHEP_INCLUDE_DIR /scratch/compiling/CLHEP_INSTALL/include
setenv CLHEP_LIB_DIR /scratch/compiling/CLHEP_INSTALL/install
