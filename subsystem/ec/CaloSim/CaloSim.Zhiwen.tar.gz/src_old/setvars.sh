#source /scratch/compiling/geant4.9.0.p02/env.csh
setenv CLHEP_BASE_DIR /scratch/compiling/CLHEP_INSTALL/
setenv CLHEP_LIB_DIR /scratch/compiling/CLHEP_INSTALL/lib
setenv CLHEP_INCLUDE_DIR /scratch/compiling/CLHEP_INSTALL/include
setenv G4VRML_HOST_NAME two.npl.uiuc.edu
