#! /bin/tcsh

rsync -avl --progress --rsh='ssh -p5262' ../CaloSim ${KIRBY2}:/home/jinhuang/work/GEANT4/test/

